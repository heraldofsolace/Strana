# PEng
Python templating engine inspired by Jinja2

PEng is a templating engine with which it's easy to generate text files using templates
